ITR - Interactive TCP Relay
Copyright (C) 2002 WebCohort Inc. All Rights Reserved.

Installation
============
Not required. Simply extract the entire zip file into a directory, then 
double click ITR.EXE

Platform Support
================
ITR was written for Win2K and is only tested to work under it.
ITR should, however, run on Win98/ME, WinNT4 and WinXP as well.

Instructions
============
Can be found in ITR-HELP.htm or by choosing the Help menu in ITR

License and Disclaimer
======================
Can be found under "Freeware License.txt"
